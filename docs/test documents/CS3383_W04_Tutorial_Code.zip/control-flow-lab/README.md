# Control Flow Testing

Open this folder in VS Code and in the course-configured OpenCode/dpsk session.
The supplied pom.xml already contains JUnit and JaCoCo. Keep it unchanged.
Java 17 or later and Maven must be available to the agent.

## Rules
### DeliveryFee
Base fee: 10. Membership reduces the fee by 2. Express delivery adds 5.
The two choices are independent. Inputs are booleans.
### BatchProcessor
A print service processes queued print jobs, at most three per batch.
Each task in the code represents one print job. A BLOCKED job needs attention,
so this batch must stop before it and leave later jobs waiting.
Process tasks in their original order. Return the zero-based positions of
completed tasks; do not modify the input list.
READY: complete the task. CANCELLED: skip it and continue.
BLOCKED: stop before processing this or any later task.
Stop as soon as three tasks have been completed.
Inputs are non-null lists containing only non-null State values. An empty list
is valid. Input length is not bounded by the three-completion limit.
### DiscountPolicy
Amounts are whole currency units from 0 through 10000.
An amount of at least 100 receives a discount of 10. Otherwise there is no discount.
Return the amount payable. Expected results must come from these rules.

## Files
src/main/java/lab: the three small examples; lab/poker contains the Poker evaluator.
src/test/java/lab: the supplied tests, including poker tests. Add tests here.
AGENTS.md supplies the shared instructions for the OpenCode session.
Do not change DeliveryFee or BatchProcessor. Change DiscountPolicy or PokerHandEvaluator only when asked, after
an assertion fails and the failure has been checked against the rules above.

## PokerHandEvaluator
A five-card Poker hand is a list of five distinct cards, in any order.
Each card has a rank (2..10, Jack=11, Queen=12, King=13, Ace=14) and a suit
(CLUBS, DIAMONDS, HEARTS, SPADES). Inputs are non-null and valid; invalid-input
handling is outside this exercise. Do not change the input list or card order.

`classify(hand)` returns one HandType: the strongest matching category below.
`isStraight`, `isFlush`, and `isFullHouse` return booleans for their own rules;
a straight flush satisfies both isStraight and isFlush.

| Strongest first | Rule |
| --- | --- |
| STRAIGHT_FLUSH | Straight and flush together; includes 10-J-Q-K-A of one suit |
| FOUR_OF_A_KIND | Four equal ranks, plus one other card |
| FULL_HOUSE | Three equal ranks and two cards of another rank |
| FLUSH | All five cards have the same suit |
| STRAIGHT | Five distinct consecutive ranks; suits need not match |
| THREE_OF_A_KIND | Three equal ranks; the two other ranks differ |
| TWO_PAIR | Two pairs of different ranks and a fifth rank |
| ONE_PAIR | One pair and three other distinct ranks |
| HIGH_CARD | None of the above |

Ace may be low in A-2-3-4-5 or high in 10-J-Q-K-A. It cannot wrap: Q-K-A-2-3
is not a straight. Input order never changes the result. There is no separate
ROYAL_FLUSH category. Do not implement tie-breaking or compare players.

Examples (C=clubs, D=diamonds, H=hearts, S=spades):
- [2C, 3D, 4H, 5S, 6C] -> STRAIGHT.
- [2H, 5H, 8H, JH, KH] -> FLUSH.
- [7C, 7D, 7H, 9S, 9C] -> FULL_HOUSE.
- [2C, 5D, 8H, JS, KC] -> HIGH_CARD.

Card.java is the card representation; HandType.java lists results.
PokerHandEvaluator.java contains the implementation to investigate.
PokerHandEvaluatorTest.java supplies three passing examples, not a complete suite.
For each failure, compare the expected result with these rules before asking
for a repair. Keep tests that exposed confirmed defects as regression tests.
