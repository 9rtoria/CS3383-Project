package lab;

public class DiscountPolicy {
    public int payable(int amount) {
        if (amount > 100) {
            return amount - 10;
        }
        return amount;
    }
}
