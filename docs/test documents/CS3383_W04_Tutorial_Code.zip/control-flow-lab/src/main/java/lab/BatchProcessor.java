package lab;

import java.util.ArrayList;
import java.util.List;

public class BatchProcessor {
    public enum State { READY, CANCELLED, BLOCKED }

    public List<Integer> process(List<State> tasks) {
        List<Integer> completed = new ArrayList<>();
        for (int i = 0; i < tasks.size(); i++) {
            State task = tasks.get(i);
            if (task == State.CANCELLED) continue;
            if (task == State.BLOCKED) break;
            completed.add(i);
            if (completed.size() == 3) break;
        }
        return completed;
    }
}
