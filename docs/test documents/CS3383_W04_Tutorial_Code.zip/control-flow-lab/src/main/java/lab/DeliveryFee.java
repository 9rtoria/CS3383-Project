package lab;

public class DeliveryFee {
    public int calculate(boolean member, boolean express) {
        int fee = 10;
        if (member) {
            fee -= 2;
        }
        if (express) {
            fee += 5;
        }
        return fee;
    }
}
