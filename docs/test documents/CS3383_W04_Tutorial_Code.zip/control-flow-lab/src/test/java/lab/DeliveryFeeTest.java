package lab;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DeliveryFeeTest {
    private final DeliveryFee fee = new DeliveryFee();
    @Test void memberExpress() {
        assertEquals(13, fee.calculate(true, true));
    }
}
