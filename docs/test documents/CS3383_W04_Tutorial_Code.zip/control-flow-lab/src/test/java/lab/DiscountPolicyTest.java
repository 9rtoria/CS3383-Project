package lab;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DiscountPolicyTest {
    private final DiscountPolicy policy = new DiscountPolicy();
    @Test void belowThreshold() {
        assertEquals(80, policy.payable(80));
    }
    @Test void aboveThreshold() {
        assertEquals(110, policy.payable(120));
    }
}
