package lab;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static lab.BatchProcessor.State.*;

class BatchProcessorTest {
    private final BatchProcessor processor = new BatchProcessor();
    @Test void threeReady() {
        assertEquals(List.of(0, 1, 2),
            processor.process(List.of(READY, READY, READY)));
    }
}
