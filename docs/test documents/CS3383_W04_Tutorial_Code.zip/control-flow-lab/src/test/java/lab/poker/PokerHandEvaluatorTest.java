package lab.poker;

import java.util.List;
import org.junit.jupiter.api.Test;
import static lab.poker.Card.Suit.*;
import static lab.poker.HandType.*;
import static org.junit.jupiter.api.Assertions.*;

class PokerHandEvaluatorTest {
    private final PokerHandEvaluator evaluator = new PokerHandEvaluator();

    @Test void orderedStraight() {
        List<Card> hand = List.of(new Card(2, CLUBS), new Card(3, DIAMONDS),
            new Card(4, HEARTS), new Card(5, SPADES), new Card(6, CLUBS));
        assertTrue(evaluator.isStraight(hand));
        assertEquals(STRAIGHT, evaluator.classify(hand));
    }

    @Test void allHearts() {
        List<Card> hand = List.of(new Card(2, HEARTS), new Card(5, HEARTS),
            new Card(8, HEARTS), new Card(11, HEARTS), new Card(13, HEARTS));
        assertTrue(evaluator.isFlush(hand));
        assertEquals(FLUSH, evaluator.classify(hand));
    }

    @Test void threeAndTwo() {
        List<Card> hand = List.of(new Card(7, CLUBS), new Card(7, DIAMONDS),
            new Card(7, HEARTS), new Card(9, SPADES), new Card(9, CLUBS));
        assertTrue(evaluator.isFullHouse(hand));
        assertEquals(FULL_HOUSE, evaluator.classify(hand));
    }
}
