package org.newdawn.spaceinvaders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.image.BufferedImage;

import org.junit.jupiter.api.Test;

/**
 * Simple unit tests for the Space Invaders entities.
 */
class SpaceInvadersTest {

    /** A minimal concrete entity that lets us control the sprite directly. */
    private static class TestEntity extends Entity {
        TestEntity(int x, int y, int w, int h) {
            super(x, y);
            this.sprite = new Sprite(new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB));
        }

        @Override
        public void collidedWith(Entity other) {
            // nothing to do
        }
    }

    @Test
    void entityMovesAccordingToSpeedAndDelta() {
        TestEntity e = new TestEntity(100, 100, 10, 10);
        e.setHorizontalMovement(100);   // 100 px/sec
        e.setVerticalMovement(-50);     // -50 px/sec

        e.move(1000);   // 1 second

        assertEquals(200, e.getX());
        assertEquals(50, e.getY());
    }

    @Test
    void entityMoveWithZeroDeltaLeavesPositionUnchanged() {
        TestEntity e = new TestEntity(40, 60, 10, 10);
        e.setHorizontalMovement(300);
        e.setVerticalMovement(300);

        e.move(0);

        assertEquals(40, e.getX());
        assertEquals(60, e.getY());
    }

    @Test
    void movementAccessorsRoundTrip() {
        TestEntity e = new TestEntity(0, 0, 10, 10);
        e.setHorizontalMovement(12.5);
        e.setVerticalMovement(-7.25);

        assertEquals(12.5, e.getHorizontalMovement());
        assertEquals(-7.25, e.getVerticalMovement());
    }

    @Test
    void getXAndGetYTruncateToInt() {
        TestEntity e = new TestEntity(5, 9, 10, 10);
        e.setHorizontalMovement(1);   // moves 0.5 px in 500ms
        e.move(500);

        assertEquals(5, e.getX());
        assertEquals(9, e.getY());
    }

    @Test
    void spriteReportsItsDimensions() {
        Sprite s = new Sprite(new BufferedImage(20, 30, BufferedImage.TYPE_INT_ARGB));
        assertEquals(20, s.getWidth());
        assertEquals(30, s.getHeight());
    }

    @Test
    void spriteStoreIsSingleton() {
        assertTrue(SpriteStore.get() == SpriteStore.get());
    }

    @Test
    void collidesWithDetectsOverlap() {
        TestEntity a = new TestEntity(10, 10, 20, 20);
        TestEntity b = new TestEntity(25, 25, 20, 20);   // overlaps by 5px
        TestEntity c = new TestEntity(100, 100, 10, 10); // far away

        assertTrue(a.collidesWith(b));
        assertFalse(a.collidesWith(c));
    }

    @Test
    void collidesWithIsFalseWhenSeparated() {
        TestEntity a = new TestEntity(0, 0, 10, 10);
        TestEntity b = new TestEntity(20, 0, 10, 10);
        assertFalse(a.collidesWith(b));
    }
}